package com.example.myfirstbluetooth;

import androidx.appcompat.app.AppCompatActivity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Intent;
import android.os.Handler;
import android.widget.Button;
import android.view.View;
import android.os.Bundle;
import android.widget.CompoundButton;
import android.widget.ListView;
import java.util.Set;
import android.widget.Switch;
import android.widget.Toast;
import java.util.ArrayList;
import android.widget.ArrayAdapter;

public class MainActivity extends AppCompatActivity {
    Button btnPaired,btnExit;
    private BluetoothAdapter BtAdpt;
    private int REQUEST_TO_ENABLE_BT = 1; // Need to set any positive integer
    private Set<BluetoothDevice>mypairedDevices;
    ListView listview;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnPaired = (Button) findViewById(R.id.paired_devices);
        btnExit=(Button)findViewById(R.id.exit);
        final Switch sw = findViewById(R.id.bt_switch);
        BtAdpt = BluetoothAdapter.getDefaultAdapter();
        if (BtAdpt == null) {
            // If the adapter is null it means that the device does not support Bluetooth
            Toast.makeText(getApplicationContext(), getResources().getString(R.string.no_bluetooth),Toast.LENGTH_SHORT).show();
            finish();
        }

        if (BtAdpt.isEnabled())
            sw.setChecked(true);
        else
            sw.setChecked(false);

        sw.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    if (!BtAdpt.isEnabled()) {
                        Intent BtOn = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                        startActivityForResult(BtOn,REQUEST_TO_ENABLE_BT );


                    }
                    // The toggle is enabled
                } else {
                    BtAdpt.disable();
                    listview.setAdapter(null);//clear list view
                    Toast.makeText(getApplicationContext(), "Bluetooth turned off" ,Toast.LENGTH_LONG).show();
                }

            }
        });

        listview = (ListView)findViewById(R.id.listView);
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_TO_ENABLE_BT)
        {
            if (resultCode == 0)
            {
               //User decided not to enable blue tooth.

                Toast.makeText(this, "With bluetooth disable this application cannot run properly. Application is exiting..", Toast.LENGTH_LONG).show();
                //exit application
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        finish();
                    }
                }, 5000);

            }

        }
    }
    public void listPaired(View v){
        listview.setAdapter(null);//clear list view
        if (!BtAdpt.isEnabled())
        {
            Toast.makeText(getApplicationContext(), getResources().getString(R.string.show_error),Toast.LENGTH_SHORT).show();

            return;
        }
        mypairedDevices = BtAdpt.getBondedDevices();
        ArrayList list = new ArrayList();
        if(!mypairedDevices.isEmpty()) {
            for (BluetoothDevice bt : mypairedDevices) list.add(bt.getName());
            Toast.makeText(getApplicationContext(), getResources().getString(R.string.show_paired),Toast.LENGTH_SHORT).show();
        }
        else {
            list.add(getResources().getString(R.string.no_device));
            Toast.makeText(getApplicationContext(), getResources().getString(R.string.no_device),Toast.LENGTH_SHORT).show();

        }


        final ArrayAdapter adapter = new  ArrayAdapter(this,android.R.layout.simple_list_item_1, list);

        listview.setAdapter(adapter);
    }

    public void exitApp(View V)
    {
        finish();

    }

}
